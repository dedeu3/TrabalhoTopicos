/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.jsf;

import br.entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author giovanacgois
 */
@Named(value = "jsfLogar")
@SessionScoped
public class JsfLogar implements Serializable {

    private Usuario usuario;
    
    public void login(String email, String pin) {
        EntityManager em = br.crud.CrudUsuario.getEntityManager();

        List<Usuario> results = em.createQuery(
        "select u from usuario u where u.email=:email and u.pin=:pin"
        )
           .setParameter("email", email)
                .setParameter("pin", pin)
                .getResultList();

        if (!results.isEmpty()) {
            usuario = results.get(0);

        }

    }

    public void logout() {

        usuario = null;

    }

    public boolean isLoggedIn() {

        return usuario != null;

    
    }

}
